package com.example.smartcleanerai

import android.app.Activity
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.util.Locale

private val Navy = Color(0xFF07111F)
private val Panel = Color(0xFF102238)
private val Cyan = Color(0xFF25D9F8)
private val Pale = Color(0xFFEAF6FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CleanerScreen() }
    }
}

@Composable
fun CleanerScreen() {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val stats = remember(refresh) { storageStats() }
    val suggestions = remember(refresh) { scanAccessibleFiles() }
    val advice = remember(refresh) { makeAiAdvice(stats.first, stats.second, suggestions) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, background = Navy, surface = Panel,
        onPrimary = Navy, onBackground = Pale, onSurface = Pale
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
                        Text("✦", color = Cyan, fontSize = 30.sp, modifier = Modifier.padding(14.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("SMART CLEANER", color = Pale, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                        Text("AI Storage Assistant", color = Cyan, fontSize = 13.sp)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("مساحة الجهاز", color = Pale, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("المستخدم: ${formatBytes(stats.first)}", color = Pale)
                        Text("المتاح: ${formatBytes(stats.second)}", color = Cyan, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        val total = (stats.first + stats.second).coerceAtLeast(1L)
                        LinearProgressIndicator(
                            progress = { stats.first.toFloat() / total.toFloat() },
                            modifier = Modifier.fillMaxWidth().height(8.dp),
                            color = Cyan,
                            trackColor = Color(0xFF294158)
                        )
                        Text("النسبة المستخدمة: ${((stats.first * 100) / total)}%", color = Pale)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("مساعد AI الذكي", color = Cyan, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(advice, color = Pale, lineHeight = 22.sp)
                        Text("ملاحظة: التحليل الحالي محلي بقواعد ذكية ولا يرسل بياناتك للإنترنت.", color = Color.LightGray, fontSize = 12.sp)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("ملفات كبيرة يمكن مراجعتها", color = Cyan, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        if (suggestions.isEmpty()) {
                            Text("لم يتم العثور على ملفات كبيرة في المجلدات العامة التي يستطيع التطبيق الوصول إليها.", color = Pale)
                        } else {
                            suggestions.take(8).forEach { item ->
                                Text("• ${item.name} — ${formatBytes(item.length())}", color = Pale)
                            }
                        }
                        Text("هذه قائمة للمراجعة فقط؛ لا يتم حذف أي ملف تلقائيًا.", color = Color.LightGray, fontSize = 12.sp)
                    }
                }
                Button(
                    onClick = { refresh++ },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Navy)
                ) { Text("إعادة الفحص", fontWeight = FontWeight.Bold) }

                OutlinedButton(
                    onClick = {
                        try {
                            context.startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))
                        } catch (_: Exception) {
                            context.startActivity(Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS))
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("فتح إعدادات التخزين والتنظيف") }

                Text(
                    "لأمان ملفاتك: أندرويد لا يسمح للتطبيق بحذف كاش التطبيقات الأخرى أو تفريغ سلالها تلقائيًا. راجع الملفات بنفسك قبل حذفها.",
                    color = Color.LightGray, fontSize = 12.sp, lineHeight = 18.sp
                )
            }
        }
    }
}

private fun storageStats(): Pair<Long, Long> {
    return try {
        val path = Environment.getDataDirectory()
        val stat = StatFs(path.path)
        val total = stat.totalBytes
        val free = stat.availableBytes
        Pair((total - free).coerceAtLeast(0L), free)
    } catch (_: Exception) { Pair(0L, 0L) }
}

private fun scanAccessibleFiles(): List<File> {
    val dirs = listOf(
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
    )
    return dirs.flatMap { dir ->
        try {
            if (dir.exists() && dir.isDirectory) dir.walkTopDown().maxDepth(4)
                .filter { it.isFile && it.length() > 50L * 1024L * 1024L }.toList()
            else emptyList()
        } catch (_: Exception) { emptyList() }
    }.distinctBy { it.absolutePath }.sortedByDescending { it.length() }.take(20)
}

private fun makeAiAdvice(used: Long, free: Long, files: List<File>): String {
    val total = (used + free).coerceAtLeast(1L)
    val percent = used * 100 / total
    return when {
        percent >= 90 -> "المساحة شبه ممتلئة. ابدأ بمراجعة الفيديوهات والتنزيلات الكبيرة، ثم انقل المهم منها إلى مكان آمن قبل حذف أي شيء."
        percent >= 75 -> "المساحة بدأت تضيق. راجع الملفات الكبيرة والتنزيلات، واحذف فقط ما تعرف أنك لم تعد تحتاج إليه."
        files.isNotEmpty() -> "المساحة تبدو مقبولة، لكن يوجد ${files.size} ملف كبير في المجلدات العامة التي أمكن فحصها. راجعها يدويًا لتحديد ما يمكن نقله أو حذفه."
        else -> "لا توجد إشارة إلى امتلاء شديد حسب المساحة المتاحة. افحص التنزيلات والفيديوهات يدويًا إذا كنت تريد توفير مساحة إضافية."
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var index = -1
    do { value /= 1024.0; index++ } while (value >= 1024 && index < units.lastIndex)
    return String.format(Locale.US, "%.1f %s", value, units[index.coerceAtMost(units.lastIndex)])
}
